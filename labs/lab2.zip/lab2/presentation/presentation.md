---
## Front matter
lang: ru-RU
title: Лабораторная работа №2
author: |
	Подмогильный Иван Александрович - студент группы НПМмд-02-22
date: 17.09.2022

## Formatting
toc: false
slide_level: 2
theme: metropolis
header-includes:
 - \metroset{progressbar=frametitle,sectionpage=progressbar,numbering=fraction}
 - '\makeatletter'
 - '\beamer@ignorenonframefalse'
 - '\makeatother'
aspectratio: 43
section-titles: true
---

# Работа с я языком легковесной разметки Markdown

## Прагматика выполнения

Умение пользоваться языком легковесной разметки Markdown

## Цель выполнения лабораторной работы

Освоить на практике использование легковесного языка Markdown

## Задачи выполнения работы

Написать отчёт по предыдущей лабораторной работе на языке Markdown

## Результаты выполнения лабораторной работы.

Отчёт изначально создавался с языком разметки Markdown со всеми приведенными рекомендациями

## Выводы

Освоил на практике применение легковесного языка Markdown
